<?php
/**
* 
*/

namespace WCFE\Services\Editor\MenuPages\Editor;

# MVC Framework
use WPPFW\MVC\MVCViewDispatcher;

/**
* 
*/
class Editor extends MVCViewDispatcher {}
