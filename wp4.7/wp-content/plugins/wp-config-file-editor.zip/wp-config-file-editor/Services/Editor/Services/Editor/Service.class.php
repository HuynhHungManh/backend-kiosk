<?php
/**
* 
*/

# Define namespace
namespace WCFE\Services\Editor\Services\Editor;

# MVC Dispatcher framework
use WPPFW\MVC\MVCDispatcher;

/**
* 
*/
class Service extends MVCDispatcher {}