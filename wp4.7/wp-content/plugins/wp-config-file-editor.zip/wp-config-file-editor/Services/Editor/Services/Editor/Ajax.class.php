<?php
/**
* 
*/

# Define namespace
namespace WCFE\Services\Editor\Services\Editor;

# Ajax service Framework
use WPPFW\Services\Dashboard\Ajax\AjaxAccessPoint;

/**
* 
*/
class Ajax extends AjaxAccessPoint {}