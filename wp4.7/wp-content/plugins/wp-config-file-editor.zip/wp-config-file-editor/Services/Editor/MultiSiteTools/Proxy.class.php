<?php
/**
* 
*/

namespace WCFE\Services\Editor\MultiSiteTools;

/**
* 
*/
class Proxy extends \WPPFW\Services\ProxyBase
{
	
}