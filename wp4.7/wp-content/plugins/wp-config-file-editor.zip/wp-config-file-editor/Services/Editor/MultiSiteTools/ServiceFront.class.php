<?php
/**
* 
*/

namespace WCFE\Services\Editor\MultiSiteTools;

/**
* 
*/
class ServiceFront extends \WPPFW\MVC\MVCViewDispatcher
{
	
}