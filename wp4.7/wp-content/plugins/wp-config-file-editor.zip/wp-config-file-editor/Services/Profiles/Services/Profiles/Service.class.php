<?php
/**
* 
*/

# Define namespace
namespace WCFE\Services\Profiles\Services\Profiles;

# MVC Dispatcher framework
use WPPFW\MVC\MVCDispatcher;

/**
* 
*/
class Service extends MVCDispatcher {}