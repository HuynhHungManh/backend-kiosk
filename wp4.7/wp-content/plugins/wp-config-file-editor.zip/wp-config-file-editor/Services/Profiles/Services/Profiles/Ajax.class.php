<?php
/**
* 
*/

# Define namespace
namespace WCFE\Services\Profiles\Services\Profiles;

# Ajax service Framework
use WPPFW\Services\Dashboard\Ajax\AjaxAccessPoint;

/**
* 
*/
class Ajax extends AjaxAccessPoint {}