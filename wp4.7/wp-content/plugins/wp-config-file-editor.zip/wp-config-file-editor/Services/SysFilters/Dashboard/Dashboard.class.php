<?php
/**
* 
*/

namespace WCFE\Services\SysFilters\Dashboard;

# MVC Framework
use WPPFW\MVC\MVCViewDispatcher;

/**
* 
*/
class Dashboard extends MVCViewDispatcher {}
