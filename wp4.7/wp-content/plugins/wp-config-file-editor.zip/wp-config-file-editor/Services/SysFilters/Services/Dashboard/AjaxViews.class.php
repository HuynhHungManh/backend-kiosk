<?php
/**
* 
*/

# Define namespace
namespace WCFE\Services\SysFilters\Services\Dashboard;

# Ajax service Framework
use WPPFW\Services\Dashboard\Ajax\AjaxAccessPoint;

/**
* 
*/
class AjaxViews extends AjaxAccessPoint {}