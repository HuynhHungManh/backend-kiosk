<?php
/**
* 
*/

# Define namespace
namespace WCFE\Services\SysFilters\Services\Dashboard;

# MVC Dispatcher framework
use WPPFW\MVC\MVCDispatcher;

/**
* 
*/
class Service extends MVCDispatcher {}