<?php
/**
* 
*/

namespace WCFE\Modules\Editor\Controller;

# JSON Responder framework
use WPPFW\MVC\Service\JSONEncoder;

/**
* 
*/
class JSONControllerResponder extends JSONEncoder {}