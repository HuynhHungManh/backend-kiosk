<?php
/**
* 
*/

# Define namespace
namespace WCFE\Modules\Editor\Model\Forms\Fields;

/**
* 
*/
interface IWPConfigFileField {
	
	/**
	* 
	*/
	public function read();
	
}