<?php
/**
* 
*/

# Define namespace
namespace WCFE\Modules\Editor\Model\ConfigFile\Fields\Types;

/**
* 
*/
interface Itype {
	
	/**
	* 
	*/
	public function prepareValue($value);
	
}