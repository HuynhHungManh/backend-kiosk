<?php
/**
* 
*/

# Define namespace
namespace WCFE\Modules\Editor\Model\ConfigFile\Fields;

/**
* 
*/
class CookieAuth extends CookieNamedBase {

	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $cookiePrefix = 'wordpress_';

  /**
  * put your comment there...
  * 
  * @var mixed
  */
	protected $comments = array
	(
		''
	);

	/**
	* put your comment there...
	* 	
	* @var mixed
	*/
	protected $name = 'AUTH_COOKIE';

}

