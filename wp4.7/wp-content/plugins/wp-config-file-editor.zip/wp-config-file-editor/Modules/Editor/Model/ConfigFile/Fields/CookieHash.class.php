<?php
/**
* 
*/

# Define namespace
namespace WCFE\Modules\Editor\Model\ConfigFile\Fields;

/**
* 
*/
class CookieHash extends CookieNamedBase {

  /**
  * put your comment there...
  * 
  * @var mixed
  */
	protected $comments = array
	(
		'Cookies Hash'
	);

	/**
	* put your comment there...
	* 	
	* @var mixed
	*/
	protected $name = 'COOKIEHASH';

}

