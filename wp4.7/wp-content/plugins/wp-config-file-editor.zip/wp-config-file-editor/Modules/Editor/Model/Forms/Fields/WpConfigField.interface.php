<?php
/**
* 
*/

# Define namespace
namespace WCFE\Modules\Editor\Model\Forms\Fields;

# Field base
use WPPFW\Forms\Fields\FormField;

/**
* 
*/
interface IWPConfigFileField {
	
	/**
	* 
	*/
	public function read();
	
}