<?php
/**
* 
*/

# Define namespace
namespace WCFE\Modules\Editor\Model\ConfigFile\Fields;

/**
* 
*/
class CookieUser extends CookieNamedBase {


	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $cookiePrefix = 'wordpressuser_';

  /**
  * put your comment there...
  * 
  * @var mixed
  */
	protected $comments = array
	(
		'User cookie'
	);

	/**
	* put your comment there...
	* 	
	* @var mixed
	*/
	protected $name = 'USER_COOKIE';

}

