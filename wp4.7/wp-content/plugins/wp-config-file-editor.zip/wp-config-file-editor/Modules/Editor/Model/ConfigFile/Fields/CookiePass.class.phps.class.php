<?php
/**
* 
*/

# Define namespace
namespace WCFE\Modules\Editor\Model\ConfigFile\Fields;

/**
* 
*/
class CookiePass extends CookieNamedBase {

	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $cookiePrefix = 'wordpresspass_';

  /**
  * put your comment there...
  * 
  * @var mixed
  */
	protected $comments = array
	(
		'Pass Cookie'
	);

	/**
	* put your comment there...
	* 	
	* @var mixed
	*/
	protected $name = 'PASS_COOKIE';

}

