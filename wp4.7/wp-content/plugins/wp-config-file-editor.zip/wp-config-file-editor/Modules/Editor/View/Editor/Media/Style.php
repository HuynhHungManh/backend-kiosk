<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Modules\Editor\View\Editor\Media;

# Script resource
use WPPFW\Services\Queue\StyleResource;

/**
* 
*/
class Style extends StyleResource {

	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'Style.css';
	
}