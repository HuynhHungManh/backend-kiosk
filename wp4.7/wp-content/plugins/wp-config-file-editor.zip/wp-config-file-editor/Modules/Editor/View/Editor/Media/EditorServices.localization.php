<?php


/**
* Javascript Localization var: WCFEEditorServicesL10N
*/
return array
(

    'couldntReachServerAfterConfigFileUpdated' => $this->__(     
        "WCFE Plugin couldn't reache the server after updating config file.".
        "\nThis might be because config file causes the site to get down or some changed configuration forced Log out.".
        "\n\n This error is likly done when switching when ON/OFF Multi Site feature" .
        "\n\nThis form will still open for you to decide if to want to restore config file or to just close the form" .
        "\n\n Its recommended to refresh the page after closing this form"
    ),
    
    'title_updateConfigFileWarning' => $this->__( 'UPDATING CONFIG FILE WARNING!!!' ),
    

);
