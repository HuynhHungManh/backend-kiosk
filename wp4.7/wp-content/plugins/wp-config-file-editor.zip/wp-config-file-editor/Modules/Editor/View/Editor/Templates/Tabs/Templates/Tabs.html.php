<?php                      
/**
* 	
*/

# Define namespace
namespace WCFE\Modules\Editor\View\Editor\Templates;

# No direct access
defined( 'ABSPATH' ) or die( WCFE\NO_DIRECT_ACCESS_MESSAGE );

# XML Declaration as WORDPRESS RESPORITORY SVN HOOK COMPLAINS!!!!! AMAZING HOOOOOOK!!!!!!
echo '<?xml version="1.0" encoding="utf-8" ?>';
?>
<div>
	<ul id="navigator"> </ul>
	<div id="tabs"> </div>
	<div id="wcfe-status-bar">
		<span class="status-text"> </span>
		<span class="log-text"> </span>
	</div>
</div>