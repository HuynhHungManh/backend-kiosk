<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Modules\Editor\View\Editor\Media;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class AutoPath extends ScriptResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'AutoPath.js';
	
}
