<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Modules\Editor\View\Editor\Media;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class ConfigForm extends ScriptResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'ConfigForm.js';
	
}