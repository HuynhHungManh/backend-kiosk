<?php
/**
* 
*/

/**
* WCFESetupNetworkL10N
*/
return array
(

    'confirm_writeConfigAndHtaccessCode' => $this->__( 'Would you like to write Config and htaccess Multi Sites configurations code?' ),
    'msg_internlServerError' => $this->__( 'Internal server error!' ),

);
