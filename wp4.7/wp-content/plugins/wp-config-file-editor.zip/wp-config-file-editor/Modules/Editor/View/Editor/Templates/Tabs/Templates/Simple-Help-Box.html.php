<?php                      
/**
* 	
*/

# Define namespace
namespace WCFE\Modules\Editor\View\Editor\Templates;

# No direct access
defined( 'ABSPATH' ) or die( WCFE\NO_DIRECT_ACCESS_MESSAGE );

?>
<div class="wcfe-simple-help-screen">
	<table class="help-list" cellpadding="11" cellspacing="4"> </table>
</div>