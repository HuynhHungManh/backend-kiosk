<?php
/**
* 
*/

/**
* WCFERawViewL10N
*/
return array
(

    'msg_configFileEmpty' => $this->__( 'Config File cannot be empty!!!' ),
    'msg_configFileNotStartByPHPTag' => $this->__( 'Config file should always start with <?php TAG!!!!' ),
);