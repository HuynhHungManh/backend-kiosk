<?php
/**
* 
*/

namespace WCFE\Modules\Profiles\Controller;

# JSON Responder framework
use WPPFW\MVC\Service\JSONEncoder;

/**
* 
*/
class JSONControllerResponder extends JSONEncoder {}