<?php
/**
* 
*/

namespace WCFE\Modules\Profiles\View\Profiles\Media;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class Profiles extends ScriptResource 
{
    
    /**
    * put your comment there...
    * 
    * @var mixed
    */
    protected $fileName = 'Profiles.js';
}
