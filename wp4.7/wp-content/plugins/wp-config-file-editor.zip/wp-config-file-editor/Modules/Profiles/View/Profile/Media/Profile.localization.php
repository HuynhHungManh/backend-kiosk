<?php
/**
* 
*/

/**
* 
*/
return array
(

    'msg_profileNameEmpty' => $this->__( 'Profile name cannot be empty' ),
    

);
