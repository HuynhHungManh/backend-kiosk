<?php
/**
* 
*/

/**
* 
* 
*/
return array
(

    'confirm_deleteSelected' => $this->__( 'Would you like to delete selected profiles?' ),
    'title_createProfile' => $this->__( 'Create Profile' ),
    

);