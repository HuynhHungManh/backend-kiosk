<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Modules\Profiles\View\Profiles\Media;

# Script resource
use WPPFW\Services\Queue\StyleResource;

/**
* 
*/
class Style extends StyleResource {

	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'List.css';
	
}