<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Modules\Profiles\View\Profile\Media;

# Script resource
use WPPFW\Services\Queue\StyleResource;

/**
* 
*/
class EditCSS extends StyleResource {

	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'Edit.css';
	
}