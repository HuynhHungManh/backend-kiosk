<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Modules\Profiles\View\Profile\Media;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class Profile extends ScriptResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'Profile.js';
	
}