<?php
/**
* 
*/

namespace WCFE\Modules\Profiles\Model;

# Models Framework
use WPPFW\MVC\Model\EntityModel;

/**
* 
*/
class Profile extends EntityModel 
{
	public $description;
	public $id;
	public $name;
	public $vars;
	
}
	