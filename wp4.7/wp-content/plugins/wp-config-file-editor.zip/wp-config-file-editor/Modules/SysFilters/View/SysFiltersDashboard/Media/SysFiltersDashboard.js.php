<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Modules\SysFilters\View\SysFiltersDashboard\Media;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class SysFiltersDashboard extends ScriptResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'SysFiltersDashboard.js';
	
}