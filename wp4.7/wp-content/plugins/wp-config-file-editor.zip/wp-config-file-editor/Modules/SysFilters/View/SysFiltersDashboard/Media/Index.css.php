<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Modules\SysFilters\View\SysFiltersDashboard\Media;

# Script resource
use WPPFW\Services\Queue\StyleResource;

/**
* 
*/
class IndexStyle extends StyleResource {

	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'Index.css';
	
}