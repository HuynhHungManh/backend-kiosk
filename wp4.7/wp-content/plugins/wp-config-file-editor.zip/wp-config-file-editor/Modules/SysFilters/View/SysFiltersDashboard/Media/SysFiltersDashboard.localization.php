<?php
/**
* 
*/

/**
* WCFESysFiltersDashboardL10N
*/
return array
(

    'title_helpDialog' => $this->__( 'WCFE Help' ),
    'btn_addType' => $this->__( 'Add Type' ),
    'btn_associateExtension' => $this->__( 'Associate Extension' ),
    'btn_addTag' => $this->__( 'Add Tag' ),
    'btn_addAttribute' => $this->__( 'Add Attribute' ),
);

