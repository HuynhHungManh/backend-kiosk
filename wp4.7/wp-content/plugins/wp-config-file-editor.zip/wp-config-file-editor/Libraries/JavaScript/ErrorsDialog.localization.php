<?php
/**
* 
*/

/**
* 
*/
return array
(
    'title' => $this->__( 'Config File Editor Errors' ),
);