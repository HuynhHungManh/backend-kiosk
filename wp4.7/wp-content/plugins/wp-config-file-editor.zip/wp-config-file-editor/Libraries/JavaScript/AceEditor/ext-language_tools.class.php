<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Libraries\JavaScript\AceEditor;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class ACEExtLanguageTools extends ScriptResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'ext-language_tools.js';
	
}