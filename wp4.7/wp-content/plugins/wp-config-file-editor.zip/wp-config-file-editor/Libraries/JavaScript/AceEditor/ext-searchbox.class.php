<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Libraries\JavaScript\AceEditor;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class ACEExtSearchBox extends ScriptResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'ext-searchbox.js';
	
}