<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Libraries\JavaScript;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class jQueryMenu extends ScriptResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'jquery-menu-ui.min.js';
	
}