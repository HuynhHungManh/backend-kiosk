<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Libraries\JavaScript;

# Script resource
use WPPFW\Services\Queue\ScriptResource;

/**
* 
*/
class ChechboxList extends ScriptResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'checkbox-list.js';
	
}