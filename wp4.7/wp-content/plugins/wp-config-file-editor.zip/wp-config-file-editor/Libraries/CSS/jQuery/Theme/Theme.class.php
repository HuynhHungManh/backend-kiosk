<?php
/**
* 
*/

/**
* 
*/
namespace WCFE\Libraries\CSS\jQuery\Theme;

# Script resource
use WPPFW\Services\Queue\StyleResource;

/**
* 
*/
class Theme extends StyleResource {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $fileName = 'jquery-ui.min.css';
	
}